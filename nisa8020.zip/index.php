<?php
$_POST['hook_page']='start';
require_once __DIR__.'/controller.php';
?>