<?php

class Start {

   private static $db_class;

   public function __construct(Db_class $db_class) {
      self::$db_class=$db_class;
   }

   public function query() {

   //...

   }
}

class Add {

   private static $db_class;

   public function __construct(Db_class $db_class) {
      self::$db_class=$db_class;
   }

   public function query() {
         $validate_parameters=array(
            array('login'=>$_POST['login'],
                  'password'=>$_POST['password'],
                 ),
            array('login'=>'email',
                  'password'=>'required',
                 ),
         );
         if($message=self::$db_class->DB_validate($validate_parameters)) {
            echo json_encode($message);
         }
         else {
            $login=mysqli_real_escape_string(self::$db_class->link_db, $_POST['login']);
            $query="select id from users where login='$login'";
            $result=mysqli_query(self::$db_class->link_db, $query);
            if(mysqli_num_rows($result)>0) {
               $message['dubl']='this login already is use';
               echo json_encode($message);
            }
            else {
               $password=mysqli_real_escape_string(self::$db_class->link_db, $_POST['password']);
               $query="insert into users(login, password) values('$login', '$password')";
               mysqli_query(self::$db_class->link_db, $query);
               $message['add']='<span style="color:green;">the adding was a success</span>';
               echo json_encode($message);
            }
         }
   }
}

class Login {

   private static $db_class;

   public function __construct(Db_class $db_class) {
      self::$db_class=$db_class;
   }

   public function query() {
         $login=mysqli_real_escape_string(self::$db_class->link_db, $_POST['login']);
         $password=mysqli_real_escape_string(self::$db_class->link_db, $_POST['password']);
         $login=mysqli_real_escape_string(self::$db_class->link_db, $_POST['login']);
         $query="select id from users where login='$login' and password='$password'";
         $result=mysqli_query(self::$db_class->link_db, $query);
         if(mysqli_num_rows($result)>0) {
            $message['login']='<span style="color:green;">Hi!</span>';
            echo json_encode($message);
         }
         else {
            $message['error_access']='Error access!';
            echo json_encode($message);
         }
   }
}

class radioChecked {

   public $radio_strategy='';

   public function __construct($radio_strategy='') {
      $this->radio_strategy=$radio_strategy;
   }

   public function checkedRadio_strategy($obj) {
   if($this->radio_strategy=='start') {
         $checked = new Start($obj);
   }
   if($this->radio_strategy=='add') {
         $checked = new Add($obj);
   }
   if($this->radio_strategy=='login') {
         $checked = new Login($obj);
   }

      return $checked->query();
   }

}

?>