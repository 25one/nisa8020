<?php
class Dom_start
{
  public function Dom($out)
  {

     ?>

<html>
<head>
<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<link rel="shortcut icon" href="faviconka_ru_137.png">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="app.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="script.js"></script>
</head>
<body>

<div class="row" style="padding-top:2em;">
 <div class="col-md-12 text-center">
  <div class="col-md-4 col-sm-3 col-xs-12 text-center">
  </div>
  <div class="col-md-4 col-sm-6 col-xs-12 text-center">
    <form name="form_people">

     <div class="table">

      <div class="row_td">
      <div class="cell_td_title" id="div_add" style="background-color:whihesmoke;text-align:center;border:1px solid silver;">
      <a href="#" id="link_add">Add User</a>
      </div>
      <div class="cell_td_title" id="div_login" style="background-color:silver;text-align:center;border:1px solid silver;">
      <a href="#" id="link_login">Login</a>
      </div>
      </div>

     </div>

     <div class="table" style="border:1px solid silver;border-radius:2px;padding:0.5em;background-color:white;">
      <div class="row_td">
      <div class="cell_td_title">
      E-Mail Address:
      </div>
      <div class="cell_td_input" id="div_email" style="background-color:white;">
          <input type="text" name="email" id="input_email" class="text" maxlength="100" />
          <div id="input_div_email" style="display:none;"></div>
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td_title">
      Password
      </div>
      <div class="cell_td_input" id="div_password" style="background-color:white;">
          <input type="text" name="password" id="input_password" class="text" maxlength="100" />
          <div id="input_div_password" style="display:none;"></div>
      </div>
      </div>

      <div class="row_td" style="height:6em;">
      <div class="cell_td_title" style="background-color:white;">
          <button type="button" class="button" id="button_add">Add</button>
          <button type="button" class="button" id="button_login" style="display:none;">Login</button>
      </div>
      <div class="cell_td_input" style="background-color:white;">
      <div id="error_success" style="font-size:1em;"></div>
      <div id="time_success_end" style="font-size:1em;color:blue;font-weight:bold;"></div>
      </div>
      </div>

     </div>

    </form>

  </div>
  <div class="col-md-4 col-sm-3 col-xs-12 text-center">
  </div>
 </div>
</div>

</body>
</html>

     <?php

  }
}
?>
