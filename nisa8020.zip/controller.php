<?php
require_once 'class.php';
$obj=new DB_class();

require_once 'rules.php';

$hook_page=mysqli_real_escape_string($obj->link_db, $_POST['hook_page']);

require_once 'Strategy.php';
$obj_strategy=new radioChecked($hook_page);
$out=$obj_strategy->checkedRadio_strategy($obj);

require_once 'Factory.php';
if($hook_page!=='add' && $hook_page!=='login') {
$result = Factory_Dom::Hook($hook_page);
echo($result->Dom($out));
}

$obj->DB_close();
?>
