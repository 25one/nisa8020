﻿$(document).ready(function() {
$("body").on("click", "#link_add", function() {add_login.view_add();return false;});
$("body").on("click", "#link_login", function() {add_login.view_login();return false;});
$("body").on("click", "#button_add", function() {add_login.validate(form_people.email.value, form_people.password.value);});
$("body").on("click", "#button_login", function() {add_login.login(form_people.email.value, form_people.password.value);});
});

var int;

var add_login={

   d_start:0,

   view_add: function() {
      $("#div_add").css("background-color", "whitesmoke");
      $("#div_login").css("background-color", "silver");
      $("#button_add").css("display", "block");
      $("#button_login").css("display", "none");
      $("#input_email").css("display", "block");
      $("#input_password").css("display", "block");
      $("#input_div_email").css("display", "none");
      $("#input_div_password").css("display", "none");
      form_people.email.value="";
      form_people.password.value="";
      $("#error_success").html("");
      clearInterval(int);
      $("#time_success_end").html("");
   },

   view_login: function() {
      $("#div_add").css("background-color", "silver");
      $("#div_login").css("background-color", "whitesmoke");
      $("#button_add").css("display", "none");
      $("#button_login").css("display", "block");
      $("#input_email").css("display", "block");
      $("#input_password").css("display", "block");
      $("#input_div_email").css("display", "none");
      $("#input_div_password").css("display", "none");
      form_people.email.value="";
      form_people.password.value="";
      $("#error_success").html("");
      clearInterval(int);
      $("#time_success_end").html("");
   },

   validate: function(email_value, password_value) {
      var error_str="";
      var r=/^(\w+\.)*\w+@[-\w]+(\.[-\w]+)+$/i;
      if(!r.test(email_value)) {
         error_str+="<span style='color:red;'>login - not valid email</span><br/>";
      }
      if(password_value=="") {
         error_str+="<span style='color:red;'>password - must be not empty</span><br/>";
      }
      if(error_str=="") {
         this.add(email_value, password_value);
      }
      else {
         $("#error_success").html(error_str);
      }
   },

   add: function(email_value, password_value) {
      var ajaxSettings = {
          method: "POST",
          data: "hook_page=add&login="+email_value+"&password="+password_value,
          url: "controller.php",
          success: function(data) {
              var json_date=JSON.parse(data);
              var json_str="";
              for(var i in json_date) {json_str+="<span style='color:red;'>"+json_date[i]+"</span><br/>";}
              $("#error_success").html(json_str);
          }
      };
      $.ajax(ajaxSettings);
   },

   login: function(email_value, password_value) {
      var ajaxSettings = {
          method: "POST",
          data: "hook_page=login&login="+email_value+"&password="+password_value,
          url: "controller.php",
          success: function(data) {
              var json_date=JSON.parse(data);
              var json_str="";
              for(var i in json_date) {
                 json_str+="<span style='color:red;'>"+json_date[i]+"</span><br/>";
                 if(i=="login") {
                    $("#input_email").css("display", "none");
                    $("#input_password").css("display", "none");
                    $("#input_div_email").css("display", "block");
                    $("#input_div_password").css("display", "block");
                    $("#input_div_email").html(email_value);
                    $("#input_div_password").html(password_value);
                    $("#button_login").css("display", "none");
                    d_start=new Date();
                    int=setInterval('add_login.func_time(d_start.getTime())', 1000);
                 }
              }
              $("#error_success").html(json_str);
          }
      };
      $.ajax(ajaxSettings);
   },

   func_time: function(d_start) {
      var d_end=new Date();
      var time_really=Math.round((parseInt(d_end.getTime())-parseInt(d_start))/1000);
      var seconds="00";
      var minutes="00";
      if(time_really/60>1) {
         minutes=Math.floor(time_really/60);
         if(minutes<10) {minutes="0"+minutes;}
         seconds=time_really-minutes*60;
         if(seconds<10) {seconds="0"+seconds;}
      }
      else {
         if(time_really<10) {seconds="0"+time_really;}
         else {seconds=time_really;}
      }
      $("#time_success_end").html(minutes+":"+seconds);
   },

}
