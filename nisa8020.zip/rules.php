<?php

$rules=array(

   'required'=>function($q) {if(!strlen($q)) {return ' must be not empty';}},
   'integer'=>function($q) {if(!is_numeric($q)) {return ' must be integer';}},
   'email'=>function($q) {if(!preg_match("/^(\w+\.)*\w+@[-\w]+(\.[-\w]+)+$/iu", $q)) {return ' not valid email';}},
   //...again

);

?>

