<?php

class Factory_Dom
{
  public static function Hook($hook)
  {
    $obj_return='Dom_'.$hook;
    require_once ('Dom_'.$hook.'.php');
    return new $obj_return;
  }
}

?>
