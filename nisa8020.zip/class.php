<?php

class DB_class {

function __construct() {
require_once 'config_db.php';
$link=mysqli_connect($db_host, $db_user, $db_password, $db_name);
if (mysqli_connect_errno()) {
    echo "Error accessing to DataBase: ".mysqli_connect_error();
    exit();
}
mysqli_query($link, "set names utf8");
$this->link_db=$link;
}

function DB_validate($validate_parameters) {
global $rules;
foreach($validate_parameters[0] as $parameter_key=>$parameter_value) {
$validate_string=$validate_parameters[1][$parameter_key];
$validate_function=$rules[$validate_string];
if($validate_function($parameter_value)) {
$errors_array[$parameter_key]=$parameter_key.' - '.$validate_function($parameter_value);
}
}
return $errors_array;
}

function DB_close() {
mysqli_close($this->link_db);
}

}

?>

