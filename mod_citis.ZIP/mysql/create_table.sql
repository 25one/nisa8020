CREATE TABLE IF NOT EXISTS `#__citis` (
	`id` int(10) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	`title` varchar(100) NOT NULL
);

INSERT INTO `#__citis` (`title`) VALUES ('Москва');
INSERT INTO `#__citis` (`title`) VALUES ('Санкт-Петербург');
